import { Injectable } from '@angular/core';

@Injectable()
export class Globals {
    VAR1 = 'value1';
    VAR2 = 'value2';
}
