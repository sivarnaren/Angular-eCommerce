export class GenderModel {
  'gender_id': number;
  'gender': string;
}

export class State {
  id: number;
  'country_id': string;
  name: string;
  abbreviation: string;
}
