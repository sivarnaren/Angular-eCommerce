export class PolicyModel {
    policyInformationId: number;
    policyName: string;
    description: string;
    policyVersion: number;
}
