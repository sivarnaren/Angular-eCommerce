export class DCIModel {
    'card_uuid': string;
    'card_content': object;
    'url': string;
}
