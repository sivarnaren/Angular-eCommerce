import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-video',
  templateUrl: './product-video.component.html',
  styleUrls: ['./product-video.component.less']
})
export class ProductVideoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
