import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-time-left-modal',
  templateUrl: './time-left-modal.component.html',
  styleUrls: ['./time-left-modal.component.less']
})
export class TimeLeftModalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
