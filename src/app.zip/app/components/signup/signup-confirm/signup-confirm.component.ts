import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-signup-confirm',
  templateUrl: './signup-confirm.component.html',
  styleUrls: ['./signup-confirm.component.less']
})
export class SignupConfirmComponent implements OnInit {

  constructor() { }

  ngOnInit() {}
}
