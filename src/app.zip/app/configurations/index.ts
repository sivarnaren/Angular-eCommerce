export * from './cookie-consent-config';
